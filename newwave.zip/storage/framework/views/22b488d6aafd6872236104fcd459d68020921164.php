
<?php $__env->startSection('title'); ?>
<?php echo e($publication->title); ?> | A Premium Media Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
   <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

        <a class="close">&times;</a>
   </div>
<?php elseif(session('warning')): ?>
   <div class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

        <a class="close">&times;</a>
   </div>    
<?php endif; ?>


    <!-- Start Banner Hero -->
    <div id="work_single_banner" class="bg-light w-100">
        <div class="container-fluid text-light d-flex justify-content-center align-items-center border-0 rounded-0 p-0 py-5">
            <div class="banner-content col-lg-8 m-lg-auto text-center py-5 px-3">
                <h1 class="banner-heading h2 pb-5 typo-space-line-center"><?php echo e($publication->title); ?></h1>
                
            </div>
        </div>
    </div>
    <!-- End Banner Hero -->

    <!-- Start Work Sigle -->
    <section class="container py-5" data-aos="zoom-in" data-aos-duration="2000">

        <div class="row pt-5">
            <div class="worksingle-content col-lg-8 m-auto text-left justify-content-center">
                <h2 class="worksingle-heading h3 pb-3 light-300 typo-space-line"><?php echo e($publication->title); ?></h2>
                <p class="worksingle-footer py-3 text-muted light-300">
                    <?php echo e($publication->description_top); ?>

                </p>
            </div>
        </div><!-- End Blog Cover -->

        <div class="row justify-content-center pb-4">
            <div class="col-lg-8">
                <div id="templatemo-slide-link-target" class="card mb-3">
                    <img class="img border rounded" src="<?php echo e(asset('/uploads/publication_images/'.$publication->image)); ?>" alt="<?php echo e($publication->title); ?>">
                </div>
            </div>
        </div><!-- End Slider -->

        <div class="row">
            <div class="col-md-8 m-auto text-left justify-content-center">
                <p class="pt-5 text-muted light-300">
                    <?php echo e($publication->description_bottom); ?>

                </p>
            </div>
        </div><!-- End Paragrph -->



        <div class="row justify-content-center">
            <div class="col-lg-8 pt-4 pb-4">
                <div class="ratio ratio-16x9">
                    <?php echo $publication->youtube_video; ?>

                </div>
            </div>
        </div><!-- End Video -->
    </section>
    <!-- End Work Sigle -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/frontend/publication.blade.php ENDPATH**/ ?>