
<?php $__env->startSection('title'); ?>
Print Publications | A Premium Media Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
   <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

        <a class="close">&times;</a>
   </div>
<?php elseif(session('warning')): ?>
   <div class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

        <a class="close">&times;</a>
   </div>    
<?php endif; ?>

   <!-- Start Banner Hero -->
   <div id="work_banner" class="banner-wrapper bg-light w-100 py-5" data-aos="fade-in" data-aos-duration="2000">
      <div class="banner-vertical-center-work container text-light d-flex justify-content-center align-items-center py-5 p-0">
          <div class="banner-content col-lg-8 col-12 m-lg-auto text-center">
              <h1 class="banner-heading h2 display-3 pb-5 semi-bold-600 typo-space-line-center">Print Publications</h1>
              <h3 class="h4 pb-2 regular-400">Only New Wave Media has the largest audience</h3>
              <p class="banner-body pb-2 light-300">
                New Wave Media’s diverse range of publications reach more B2B buyers and specifiers in the Commercial Maritime, Shallow Draft Workboat,Underwater Science, and Offshore Energy Industries than any other publications.
              </p>
              <button type="button" class="btn rounded-pill btn-primary text-light px-4 light-300" href="<?php echo e(url('/contact')); ?>">Contact Us</button>
          </div>
      </div>
  </div>
  <!-- End Banner Hero -->

  <!-- Start Our Work -->
  <section class="container py-5" data-aos="zoom-in-left" data-aos-duration="2000">
      

      <div class="row services gx-lg-5 text-center">
        <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(url('/publication/'.$publication->slug)); ?>" class="col-sm-6 col-md-6 col-lg-3 text-decoration-none service maritime py-2">
              <div class="service-work overflow-hidden card mb-5 mx-5 m-sm-0">
                  <img class="card-img-top" src="<?php echo e(asset('/uploads/publication_images/'.$publication->image)); ?>" alt="...">
                  <div class="card-body">
                      <h5 class="card-title light-300 text-dark">
                        <?php echo e($publication->title); ?>

                       </h5>
                      <p class="card-text light-300 text-dark">
                        <?php echo Str::words($publication->description_top, 1, ' ...'); ?>

                      </p>
                      <span class="text-decoration-none text-primary light-300">
                            Read more <i class='bx bxs-hand-right ms-1'></i>
                        </span>
                  </div>
              </div>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
  </section>
  <!-- End Our Work -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/frontend/print-publications.blade.php ENDPATH**/ ?>