
<?php $__env->startSection('title'); ?>
About | A Premium Media Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
   <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

        <a class="close">&times;</a>
   </div>
<?php elseif(session('warning')): ?>
   <div class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

        <a class="close">&times;</a>
   </div>    
<?php endif; ?>


    <!-- Start Banner Hero -->
    <section class="bg-light w-100">
        <div class="container">
            <div class="row d-flex align-items-center py-5">
                <div class="col-lg-6 text-start" data-aos="zoom-out-left" data-aos-duration="2000">
                    <h1 class="h2 py-5 text-primary typo-space-line">About Us</h1>
                    <p class="light-300">
                        For the past 80 years, New Wave Media and its family of publications and websites has been committed to bringing largest audience to our clients in the maritime, underwater science and offshore energy industries.
                    </p>
                </div>
                <div class="col-lg-6" data-aos="zoom-out-right" data-aos-duration="2000">
                    <img src="<?php echo e(asset('frontend/img/banner-img-02.svg')); ?>">
                </div>
            </div>
        </div>
    </section>
    <!-- End Banner Hero -->


    <!-- Start Team Member -->
    <section class="container py-5" data-aos="zoom-in" data-aos-duration="2000">
        <div class="pt-5 pb-3 d-lg-flex align-items-center gx-5">

            <div class="col-lg-3">
                <h2 class="h2 py-5 typo-space-line">Our Team</h2>
                <p class="text-muted light-300">
                    New Wave Media’s advertising specialists will help you develop a multi-platform marketing initiative to grow your business.
                </p>
            </div>

            <div class="col-lg-9 row d-flex justify-content-center">
                <div class="team-member col-md-4">
                    <img class="team-member-img img-fluid rounded-circle p-4" src="<?php echo e(asset('frontend/img/team/terry-breese.jpg')); ?>" alt="Card image">
                    <ul class="team-member-caption list-unstyled text-center pt-4 text-muted light-300">
                        <li><b>Terry Breese</b></li>
                        <li>Vice President of Sales</li>
                    </ul>
                </div>
                <div class="team-member col-md-4">
                    <img class="team-member-img img-fluid rounded-circle p-4" src="<?php echo e(asset('frontend/img/team/john-cagni.jpg')); ?>" alt="Card image">
                    <ul class="team-member-caption list-unstyled text-center pt-4 text-muted light-300">
                        <li><b>John Cagni</b></li>
                        <li>Advertising Sales Manager</li>
                    </ul>
                </div>
                <div class="team-member col-md-4">
                    <img class="team-member-img img-fluid rounded-circle p-4" src="<?php echo e(asset('frontend/img/team/lucia-annunziata.jpg')); ?>" alt="Card image">
                    <ul class="team-member-caption list-unstyled text-center pt-4 text-muted light-300">
                        <li><b>Lucia Annunziata</b></li>
                        <li>Advertising Sales Manager</li>
                    </ul>
                </div>
                <div class="team-member col-md-4">
                    <img class="team-member-img img-fluid rounded-circle p-4" src="<?php echo e(asset('frontend/img/team/mike-kozlowski.jpg')); ?>" alt="Card image">
                    <ul class="team-member-caption list-unstyled text-center pt-4 text-muted light-300">
                        <li><b>Mike Kozlowski</b></li>
                        <li>Advertising Sales Manager</li>
                    </ul>
                </div>
                <div class="team-member col-md-4">
                    <img class="team-member-img img-fluid rounded-circle p-4" src="<?php echo e(asset('frontend/img/team/frank-covella.jpg')); ?>" alt="Card image">
                    <ul class="team-member-caption list-unstyled text-center pt-4 text-muted light-300">
                        <li><b>Frank Covella</b></li>
                        <li>Advertising Sales Manager</li>
                    </ul>
                </div>
                
            </div>

        </div>
    </section>
    <!-- End Team Member -->

    <!-- Start Aim -->
    <section class="banner-bg bg-light py-5" data-aos="zoom-in" data-aos-duration="2000">
        <div class="container my-4">
            <div class="row text-center">

                <div class="objective col-lg-4">
                    <div class="objective-icon card m-auto py-4 mb-2 mb-sm-4 bg-secondary shadow-lg">
                        <i class="display-4 fa-solid fa-globe text-light"></i>
                    </div>
                    <h2 class="objective-heading h3 mb-2 mb-sm-4 light-300">1,625,082</h2>
                    <p class="light-300">
                        AVERAGE MONTHLY NETWORK PAGEVIEWS
                    </p>
                </div>

                <div class="objective col-lg-4 mt-sm-0 mt-4">
                    <div class="objective-icon card m-auto py-4 mb-2 mb-sm-4 bg-secondary shadow-lg">
                        <i class="display-4 fa-solid fa-book text-light"></i>
                    </div>
                    <h2 class="objective-heading h3 mb-2 mb-sm-4 light-300">137,618</h2>
                    <p class="light-300">
                        AVERAGE MONTHLY MAGAZINE CIRCULATION
                    </p>
                </div>

                <div class="objective col-lg-4 mt-sm-0 mt-4">
                    <div class="objective-icon card m-auto py-4 mb-2 mb-sm-4 bg-secondary shadow-lg">
                        <i class="display-4 fa-brands fa-google-play text-light"></i>
                    </div>
                    <h2 class="objective-heading h3 mb-2 mb-sm-4 light-300">91,335</h2>
                    <p class="light-300">
                        APP DOWNLOADS
                    </p>
                </div>

            </div>
        </div>
    </section>
    <!-- End Aim -->

    <!-- Start Contact -->
    
    <!-- End Contact -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/frontend/about.blade.php ENDPATH**/ ?>