<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Query Email</title>
</head>
<body>
    <div class="card">
        <div class="card-header">
            Contact Email
        </div>
        <div class="card-header">
            <p>Name : <?php echo e($details['name']); ?></p>
            <p>Email : <?php echo e($details['email']); ?></p>
            <p>Phone : <?php echo e($details['phone']); ?></p>
            <p>Address : <?php echo e($details['address']); ?></p>
            <p>Company Name : <?php echo e($details['company_name']); ?></p>
            <p>Content : <?php echo e($details['content']); ?></p>
        </div>
    </div>
</body>
</html><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/emails/contactMail.blade.php ENDPATH**/ ?>