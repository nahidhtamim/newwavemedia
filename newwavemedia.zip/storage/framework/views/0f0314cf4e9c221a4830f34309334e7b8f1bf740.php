
<?php $__env->startSection('title'); ?>
<?php echo e($digital->title); ?> | A Premium Media Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contents'); ?>

<?php if(session('status')): ?>
   <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

        <a class="close">&times;</a>
   </div>
<?php elseif(session('warning')): ?>
   <div class="alert alert-danger" role="alert">
        <?php echo e(session('warning')); ?>

        <a class="close">&times;</a>
   </div>    
<?php endif; ?>


    <!-- Start Banner Hero -->
    <div id="work_single_banner" class="bg-light w-100">
        <div class="container-fluid text-light d-flex justify-content-center align-items-center border-0 rounded-0 p-0 py-5">
            <div class="banner-content col-lg-8 m-lg-auto text-center py-5 px-3">
                <h1 class="banner-heading h2 pb-5 typo-space-line-center"><?php echo e($digital->title); ?></h1>
                
            </div>
        </div>
    </div>
    <!-- End Banner Hero -->

    <!-- Start Work Sigle -->
    <section class="container py-5" data-aos="zoom-in" data-aos-duration="2000">

        <div class="row pt-5">
            <div class="worksingle-content col-lg-8 m-auto text-left justify-content-center">
                <h2 class="worksingle-heading h3 pb-3 light-300 typo-space-line"><?php echo e($digital->title); ?></h2>
                <p class="worksingle-footer py-3 text-muted light-300">
                    <?php echo $digital->description; ?>

                </p>
            </div>
        </div><!-- End Blog Cover -->

        <div class="row justify-content-center pb-4">
            <div class="col-lg-8">
                <div id="templatemo-slide-link-target" class="card mb-3">
                    <img class="img border rounded" src="<?php echo e(asset('/uploads/digital_images/'.$digital->image)); ?>" alt="Card image cap" height="550px">
                </div>
            </div>
        </div><!-- End Slider -->

        <div class="text-center pt-5" role="group" aria-label="First group">
            <a class="btn btn-secondary rounded-pill btn-block shadow px-4 py-2 text-white" href="<?php echo e($digital->link); ?>">Please Visit</a>
        </div>
    </section>
    <!-- End Work Sigle -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/frontend/digital.blade.php ENDPATH**/ ?>