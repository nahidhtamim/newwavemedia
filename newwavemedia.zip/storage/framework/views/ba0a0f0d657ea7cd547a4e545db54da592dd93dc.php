
<?php $__env->startSection('title'); ?>
Dashboard | A Premium Media Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-contents'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

    <a href="" class="close">&times;</a>
</div>
<?php elseif(session('warning')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('warning')); ?>

    <a href="" class="close">&times;</a>
</div>
<?php endif; ?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Digitals</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Digitals List
                <button type="button" class="btn btn-success" data-toggle="modal" data-target="#exampleModal">
                    Add
                </button>
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead class="text-center">
                        <tr>
                            <th>SL.</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Description</th>
                            <th>link</th>
                            <th>File</th>
                            <th>Slug</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i=1; ?>
                        <?php $__empty_1 = true; $__currentLoopData = $digitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $digital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($digital->title); ?></td>
                                <td><img src="/uploads/digital_images/<?php echo e($digital->image); ?>" alt="" height="200px"></td>
                                <td><?php echo $digital->description; ?></td>
                                <td><?php echo $digital->link; ?></td>
                                <td><?php echo e($digital->pdf); ?></td>
                                <td><?php echo e($digital->slug); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="<?php echo e(url('/edit-digital/'.$digital->slug)); ?>" class="btn btn-primary">Edit</a>
                                        <a href="<?php echo e(url('/delete-digital/'.$digital->slug)); ?>" class="btn btn-danger">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center">No Digitals yet!</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
            aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Digital</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form class="user" action="<?php echo e(url('/add-digital')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                            
                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="title" class="text-primary"> <b>Title <span class="text-danger">*</span></b> </label>
                                <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title"
                                    placeholder="Digital Title">
                                <span class="text-danger">
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <p class="text-danger"><?php echo e($message); ?></p> 
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span>
                                <br>
                            </div>
                            <div class="col-12">
                                <label for="description" class="text-primary"> <b>Description <span class="text-danger">*</span></b> </label>
                                <textarea name="description" rows="2" id="textarea"
                                    class="form-control text-left <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    Description
                                </textarea>
                                <?php $__errorArgs = ['description_top'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <br>
                            </div>
                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="link" class="text-primary"> <b>Website Link</b> </label>
                                <input type="text" name="link" class="form-control" id="link"
                                    placeholder="Website Link">
                                <br>
                            </div>
                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="slug" class="text-primary"> <b>Slug</b> </label>
                                <input type="text" name="slug" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug"
                                    placeholder="Slug">
                                <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger"><?php echo e($message); ?></p> 
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                <br>
                            </div>
                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="image" class="text-primary"> <b>Image</b> <span class="text-danger">*</span> 
                                    <small>[Use Image of Size 800*800px]</small> 
                                </label>
                                <input type="file" name="image" class="form-control" id="image" accept="image/*">
                                <br>
                            </div>
                            <div class="col-12 mb-3 mb-sm-0">
                                <label for="pdf" class="text-primary"> <b>Docs</b>
                                </label>
                                <input type="file" name="pdf" class="form-control" id="image">
                                <br>
                            </div>
                            <div class="col-12 mb-3 mb-sm-0">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /.container-fluid -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/admin/digitals/index.blade.php ENDPATH**/ ?>