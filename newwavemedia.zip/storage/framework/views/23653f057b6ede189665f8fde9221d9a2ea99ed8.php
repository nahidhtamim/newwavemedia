
<?php $__env->startSection('title'); ?>
<?php echo e($publication->title); ?> | A Premium Media Company
<?php $__env->stopSection(); ?>
<?php $__env->startSection('admin-contents'); ?>

<?php if(session('status')): ?>
<div class="alert alert-success" role="alert">
    <?php echo e(session('status')); ?>

    <a href="" class="close">&times;</a>
</div>
<?php elseif(session('warning')): ?>
<div class="alert alert-danger" role="alert">
    <?php echo e(session('warning')); ?>

    <a href="" class="close">&times;</a>
</div>
<?php endif; ?>


<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo e($publication->title); ?></h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">
                Edit <?php echo e($publication->title); ?>

            </h6>
        </div>
        <div class="card-body">
            <form class="user" action="<?php echo e(url('/update-publication/'.$publication->slug)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="col-12 mb-3 mb-sm-0">
                    <label for="title" class="text-primary"> <b>Title <span class="text-danger">*</span></b> </label>
                    <input type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="title"
                        value="<?php echo e($publication->title); ?>">
                    <span class="text-danger">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="text-danger"><?php echo e($message); ?></p> 
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span>
                    <br>
                </div>
                <div class="col-12">
                    <label for="description_top" class="text-primary"> <b>Top Description <span class="text-danger">*</span></b> </label>
                    <textarea name="description_top" rows="2" id="textarea"
                        class="form-control text-left <?php $__errorArgs = ['description_top'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php echo $publication->description_top; ?>

                    </textarea>
                    <?php $__errorArgs = ['description_top'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                </div>
                <div class="col-12">
                    <label for="description_bottom" class="text-primary"> <b>Bottom Description</b> </label>
                    <textarea name="description_bottom" rows="2" id="textarea_two"
                        class="form-control text-left">
                        <?php echo $publication->description_bottom; ?>

                    </textarea>
                    <br>
                </div>
                <div class="col-12 mb-3 mb-sm-0">
                    <label for="youtube_video" class="text-primary"> <b>Youtube Video</b> </label>
                    <input type="text" name="youtube_video" class="form-control" id="youtube_video"
                        value="<?php echo e($publication->youtube_video); ?>">
                    <br>
                </div>
                <div class="col-12 mb-3 mb-sm-0">
                    <label for="slug" class="text-primary"> <b>Slug</b> </label>
                    <input type="text" name="slug" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="slug"
                    value="<?php echo $publication->slug; ?>">
                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p> 
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                    <br>
                </div>
                <div class="col-12 mb-3 mb-sm-0">
                    <label for="image" class="text-primary"> <b>Image</b> <span class="text-danger">*</span> 
                        <small>[Use Image of Size 800*800px]</small> 
                    </label>
                    <input type="file" name="image" class="form-control" id="image" accept="image/*">
                    <br>
                    <img src="/uploads/publication_images/<?php echo e($publication->image); ?>" alt="" height="350px" width="auto" style="border: 5px solid #113476; border-radius: 15px; margin-bottom: 25px;">
                    <br>
                </div>
                <div class="col-12 mb-3 mb-sm-0">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- /.container-fluid -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\github\newwavemedia\resources\views/admin/publications/edit.blade.php ENDPATH**/ ?>